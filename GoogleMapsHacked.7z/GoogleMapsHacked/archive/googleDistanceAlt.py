#
# Copyright 2014 Google Inc. All rights reserved.
#
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.
#

import googlemaps
import csv

myODList= open(r"C:\Users\Melkor\PycharmProjects\googleAPI\test_data\ODGoogleTest.csv", "r")
myOutputMatrix = open(r"C:\Users\Melkor\PycharmProjects\googleAPI\test_data\myDistanceMatrix.csv", "w")
myOutputMatrix.write("OBJECTID,durationMin,distanceKm, \n") # write col names of output file
inputTime = open(r"C:\Users\Melkor\PycharmProjects\googleAPI\test_data\inputTime.csv", "r")
myKey =  'AIzaSyDp5-fGIEN-TX__HhuK_Bv_K9ZKKyiCF1U'
# arrivalTime =


# myODList cols: OBJECTID,identifier,O_long,O_lat,D_long,D_lat

def googleMapsDistanceMatrix(myKey, myODList, myOutputMatrix, modeOfTransport, arrivalTime):
    return 0

# example from google: https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=Washington,DC&destinations=New+York+City,NY&key
gmaps = googlemaps.Client(key=myKey)

# OBJECTID,identifier,O_long,O_lat,D_long,D_lat <==cols

# arrival_timeList
# departure_timeList

for line in myODList.readlines():
    list = line.split(",")
    OBJECTID = list[0]
    myOrigin=(list[2], list[3])
    myDestination=(list[4], list[5])

    my_distance = gmaps.distance_matrix(myOrigin,myDestination , mode="driving")  #arrival_time="08:30", departure_time="")
    if my_distance['rows'][0]['elements'][0]['status'] != 'ZERO_RESULTS':
        durationMin = my_distance['rows'][0]['elements'][0]['duration']['value']/60
    if my_distance['rows'][0]['elements'][0]['status'] != 'ZERO_RESULTS':
        distanceKm = my_distance['rows'][0]['elements'][0]['distance']['value']/1000
    myOutputMatrix.write(str(OBJECTID)+ ", "+ str("arrivalTime") +", "+ str(durationMin)+ ", " + str(distanceKm) + "\n")

print(my_distance)

myODList.close()
myOutputMatrix.close()


# googleMapsDistanceMatrix(myKey, myODList, myOutputMatrix, modeOfTransport="driving",  )