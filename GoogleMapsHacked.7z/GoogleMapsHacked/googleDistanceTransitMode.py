#
# Copyright 2014 Google Inc. All rights reserved.
#
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.
#

import googlemaps
import csv
import time




myOrigins = [line.rstrip().split(sep="\n") for line in open(r".\data\O.csv", "r", encoding="UTF-8")]
myDestinations = [line.rstrip().split(sep="\n") for line in open(r".\data\O.csv", "r", encoding="UTF-8")]

myOutputMatrix = open(r".\data\myOutput.csv", "a", encoding="UTF-8")
# myOutputMatrix.write("OBJECTID,identifier,lat_O,long_O,lat_D,long_D,durationMin,DistanceKm, DepartureOrArrival \n") # write col names of output file

myKey =  'AIzaSyDp5-fGIEN-TX__HhuK_Bv_K9ZKKyiCF1U'

# myODList cols: OBJECTID,identifier,O_long,O_lat,D_long,D_lat
modeOfTransport="driving"
arrivalTime=""
departureTime=""

def googleMapsDistanceMatrix(myKey, myOrigins, myDestinations, myOutputMatrix, modeOfTransport, arrivalTime, departureTime):
    """" We calculate matrix of trip duration and distance between two  points.
    Input values are: table with OD matrix with lat-long and one list with time of departure or arrival (one of two, followed by right parameter)
    output is "myDistanceMatrix.csv", which is copied OD matrix input table with appended values of trip duration,
    distance and DepartureOrArrival cols.
    The code needs improvements, there are still many hardcoded parts.
    """
    # example from google: https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=Washington,DC&destinations=New+York+City,NY&key
    gmaps = googlemaps.Client(key=myKey)

    # OBJECTID,identifier,O_long,O_lat,D_long,D_lat <==cols

    # arrival_timeList
    # departure_timeList


    myOrigin = (list[2], list[3])
    myDestination = (list[4], list[5])



        my_distance = gmaps.distance_matrix(myOrigin, myDestination,
                                            mode=modeOfTransport)  # arrival_time="08:30", departure_time="")
        print(my_distance)
        durationMin = my_distance['rows'][0]['elements'][0]['duration']['value'] / 60
        print(durationMin)
        if my_distance['rows'][0]['elements'][0]['status'] != 'ZERO_RESULTS':
            distanceKm = my_distance['rows'][0]['elements'][0]['distance']['value'] / 1000

        s = ("," + str(durationMin) + ", " + str(distanceKm) + ", " + str(
            "arrival or departure") + "\n")  # change arrival or departure
        myOutputMatrix.write(line.rstrip('\n') + s)

    myODList.close()
    myOutputMatrix.close()


googleMapsDistanceMatrix(myKey, myODList, myOutputMatrix, modeOfTransport, arrivalTime, departureTime)


