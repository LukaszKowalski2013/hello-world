#
# Copyright 2014 Google Inc. All rights reserved.
#
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.
#

import googlemaps
import csv
import time

myODList= open(r".\test_data\ODGoogleTest.csv", "r") #C:\Users\Melkor\PycharmProjects\googleAPI
myOutputMatrix = open(r".\test_data\myDistanceMatrix.csv", "w")
myOutputMatrix.write("OBJECTID,identifier,lat_O,long_O,lat_D,long_D,durationMin,DistanceKm, DepartureOrArrival \n") # write col names of output file

inputTime = open(r".\test_data\inputTime.csv", "r")
myKey =  'AIzaSyDp5-fGIEN-TX__HhuK_Bv_K9ZKKyiCF1U'
# arrivalTime = ("06:00","06:30","07:00","07:30","08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30","13:00","13:30")
# departureTime = ("14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00","18:30","19:00","19:30","20:00","20:30","21:00","21:30")

# myODList cols: OBJECTID,identifier,O_long,O_lat,D_long,D_lat
modeOfTransport="driving"
arrivalTime=""
departureTime=""

def googleMapsDistanceMatrix(myKey, myODList, myOutputMatrix, modeOfTransport, arrivalTime, departureTime):
    """" We calculate matrix of trip duration and distance between two  points.
    Input values are: table with OD matrix with lat-long and one list with time of departure or arrival (one of two, followed by right parameter)
    output is "myDistanceMatrix.csv", which is copied OD matrix input table with appended values of trip duration,
    distance and DepartureOrArrival cols.
    The code needs improvements, there are still many hardcoded parts.
    """
    # example from google: https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=Washington,DC&destinations=New+York+City,NY&key
    gmaps = googlemaps.Client(key=myKey)

    # OBJECTID,identifier,O_long,O_lat,D_long,D_lat <==cols

    # arrival_timeList
    # departure_timeList

    for line in myODList.readlines():
        list = line.split(",")
        OBJECTID = list[0]
        myOrigin = (list[2], list[3])
        myDestination = (list[4], list[5])

        # gmapsNotOK = gmaps.distance_matrix(myOrigin, myDestination,
        #                                     mode=modeOfTransport) =None
        # while gmapsNotOK:
        #     time.sleep(10)
        #     gmapsNotOK = gmaps.distance_matrix(myOrigin, myDestination,
        #                                        mode=modeOfTransport) != None
        #     print('waiting ' + str(time.ctime()))
        my_distance = gmaps.distance_matrix(myOrigin, myDestination,
                                            mode=modeOfTransport)  # arrival_time="08:30", departure_time="")
        print(my_distance)
        durationMin = my_distance['rows'][0]['elements'][0]['duration']['value'] / 60
        print(durationMin)
        if my_distance['rows'][0]['elements'][0]['status'] != 'ZERO_RESULTS':
            distanceKm = my_distance['rows'][0]['elements'][0]['distance']['value'] / 1000

        s = ("," + str(durationMin) + ", " + str(distanceKm) + ", " + str(
            "arrival or departure") + "\n")  # change arrival or departure
        myOutputMatrix.write(line.rstrip('\n') + s)

    myODList.close()
    myOutputMatrix.close()


googleMapsDistanceMatrix(myKey, myODList, myOutputMatrix, modeOfTransport, arrivalTime, departureTime)


