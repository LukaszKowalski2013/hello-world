
import csv

# with open('E:/ODGoogleTest.csv', 'r') as f:
#   reader = csv.reader(f)
#   your_list = list(reader)
#

# print(your_list)

lista1= [1, 2, 3, 4, 5, 6, 4, 3, 5]

lista2= [14, 42, 43, 54, 56, 56, 34, 32, 51]

print(lista1, lista2)

for i in range(len(lista1)):
  for j in range (len(lista2)):
    print(lista1[i], lista2[j])