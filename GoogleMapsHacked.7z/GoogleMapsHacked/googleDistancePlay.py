#
# Copyright 2014 Google Inc. All rights reserved.
#
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may not
# use this file except in compliance with the License. You may obtain a copy of
# the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations under
# the License.
#

import googlemaps
import csv
import time
import pprint
import datetime
import json
import os

os.chdir(r"F:\pythonGames\PythonGames\GoogleMapsHacked")

myKey =  'AIzaSyDp5-fGIEN-TX__HhuK_Bv_K9ZKKyiCF1U'
modeOfTransport="walking"
# TransitPreference ='FEWER_TRANSFERS'
limit_of_elements = 100 # 100 for standard 625 for premium; here we check 1 to many distances

gmaps = googlemaps.Client(key=myKey)


# 1 OD
# myOrigin='304 York Rd, Leeds LS9 9DN, Wielka Brytania'
# myDestination='Moorland Rd, Leeds LS6 1AN, Wielka Brytania'
#
# my_distance = gmaps.distance_matrix(myOrigin, myDestination,
#                                     mode=modeOfTransport, arrival_time=datetime.datetime.now)    #(2017,10,11,11,11)
# print(my_distance)
#
# for i in my_distance:
#     print(i)

#2  OD matrix
# A
# O = [[ 51.483507, -0.147714],
# [51.496863, -0.142943],
# [51.514499, -0.141423],
# [51.528187, -0.075375]]
#
# D = [[ 51.483507, -0.147714],
# [51.496863, -0.142943],
# [51.514499, -0.141423],
# [51.528187, -0.075375]]

# B
O = [line.rstrip() for line in open(r".\data\O.csv", "r", encoding="UTF-8")]
D = [line.rstrip() for line in open(r".\data\D.csv", "r", encoding="UTF-8")]
firstOD = [int(line.rstrip().split(sep=":")[1]) for line in open(r".\data\firstOD.txt", "r", encoding="UTF-8")]
myOutputMatrix = open(r".\data\myOutput.csv", "a")

# my_distance = gmaps.distance_matrix(O, D, mode=modeOfTransport)
# print(my_distance)
errors=0
s="" #string to write in the file

def getDestinationsGrouped(limit_of_elements, destinations):
    even = int(len(D)/limit_of_elements)
    rest = len(D)%limit_of_elements
    out = list(limit_of_elements for x in range (0,even))
    out.append(rest)
    return out

for destinationSet in getDestinationsGrouped(limit_of_elements, D):
    next = 0
    # try:
    print(D[next:(next+destinationSet)])
    print("\n", O[0])
    print(next, next+destinationSet)

    my_distance = gmaps.distance_matrix(O[0], D[next:(next+destinationSet)], mode=modeOfTransport)

#here we read all 100 lines of our elements (max in 1 query), there is 1 loop, because we assume there is only 1 origin in Google OD matrix
    for i in range(0, 100):
        # o = my_distance['origin_addresses'][0]
        # d = my_distance['destination_addresses'][i]

        durationMin = my_distance['rows'][0]['elements'][i]['duration']['value'] / 60
        distanceKm = my_distance['rows'][0]['elements'][i]['distance']['value'] / 1000
        # write it to output file: O, D, distance
        # s += oXY + ", " + dXY +", " + str(durationMin) + ", " + str(distanceKm) + "\n"

        s = str(i) +", " + str(durationMin) + ", " + str(distanceKm) + "\n"
        myOutputMatrix.write(s)
        print(s)
    # increment firstOD file
    next+=destinationSet

myOutputMatrix.close()




# durationMin = my_distance['rows'][0]['elements'][0]['duration']['value'] / 60
# print(durationMin)
# if my_distance['rows'][0]['elements'][0]['status'] != 'ZERO_RESULTS':
#     distanceKm = my_distance['rows'][0]['elements'][0]['distance']['value'] / 1000
#

